#include "Cuadrado.h"

double Cuadrado::area() {
	return lado * lado;
}
