#ifndef CUADRADO_H
#define CUADRADO_H
#include "Figura.h"

class Cuadrado : public Figura {
public:
	double lado = 4;
	double area();
};

#endif
