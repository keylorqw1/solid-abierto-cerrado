#ifndef FIGURA_H
#define FIGURA_H

// Clase base
class Figura {
public:
	virtual ~Figura();
	virtual double area() = 0;
};

#endif
