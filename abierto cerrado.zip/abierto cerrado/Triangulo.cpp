#include "Triangulo.h"

double Triangulo::area() {
	return base * altura / 2;
}
