#ifndef TRIANGULO_H
#define TRIANGULO_H
#include "Figura.h"

// figura nueva
class Triangulo : public Figura {
public:
	double base = 6;
	double altura = 3;
	double area();
};

#endif
