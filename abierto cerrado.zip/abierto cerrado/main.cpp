#include <iostream>
#include "Cuadrado.h"
#include "Triangulo.h"
using namespace std;


void mostrarArea(Figura &figura) {
	cout << "El area es: " << figura.area() << endl;
}

int main() {
	Cuadrado cuadrado;
	Triangulo triangulo;
	
	mostrarArea(cuadrado);
	mostrarArea(triangulo);
	
	return 0;
}
